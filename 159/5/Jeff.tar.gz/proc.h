// proc.h, 159

#ifndef _PROC_H_
#define _PROC_H_


void IdleProc();
void Init();


#endif
