#ifndef _UTIL_H_
#define _UTIL_H_

#include "types.h"
#include "externs.h"

void PrintMsgQ(int index);
void PrintMsg(msg_t *p);

#endif
