#ifndef _ENTRY_H_
#define _ENTRY_H_

#define TIMER_INTR 0x20

#ifndef ASSEMBLER

void TimerEntry();

#endif

#endif
