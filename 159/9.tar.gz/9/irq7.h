// irq7.h, 159 phase 5

#ifndef _IRQ7_H_
#define _IRQ7_H_

void PrintDriver();
void PrintInit();
int PrintStr(char *);
int PrintChar(char);
void IRQ7ISR();

#endif

