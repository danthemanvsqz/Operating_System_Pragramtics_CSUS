#ifndef _MEMORY_H_
#define _MEMORY_H_

int getAvailableSpace();
void addressToWord(char *, char *);

#endif
