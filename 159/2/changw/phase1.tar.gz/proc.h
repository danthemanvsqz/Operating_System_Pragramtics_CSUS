// proc.h, 159

#ifndef _PROC_H_
#define _PROC_H_

void SimpleProc();
void IdleProc();


#endif
